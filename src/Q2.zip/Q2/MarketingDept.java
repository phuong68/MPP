package Q2;

public class MarketingDept extends Department{
	//implement
	
	public void applyForJob() {
		//not implemented
	}

	@Override
	String getName() {
		return "Marketing";
	}
}
