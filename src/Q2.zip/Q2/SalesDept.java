package Q2;

public class SalesDept extends Department{
	//implement
	
	
	public void requestMarketingMaterials() {
		//not implemented
	}

	@Override
	String getName() {
		return "Sales";
	}
}
