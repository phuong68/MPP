package Q1;

public class LendingItem {
	private int numCopiesLnLib;

	public int getNumCopiesLnLib() {
		return numCopiesLnLib;
	}

	public void setNumCopiesInLib(int numCopiesLnLib) {
		this.numCopiesLnLib = numCopiesLnLib;
	}
	
	

	
	
}
