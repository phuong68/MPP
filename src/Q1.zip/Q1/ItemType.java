package Q1;

public enum ItemType {
	BOOK, CD;
}
